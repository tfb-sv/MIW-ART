﻿For installation instructions refer to the FBE web page
if you don't have an idea on how to use LaTeX.
(Hint: Frequently Seen Mistakes Section)


Quick tip: As of 2016 www.sharelatex.com is a very easy way
of importing the fbe_thesis_2016.zip file as a project and
start writing your thesis in LaTeX.



Or you can install MikTeX 2.9+ into your computer and use
TeXStudio, which is only a bit slower to start with but
extremely easy and efficient to use.

Usage of LaTeX is highly recommended as it formats many of
the thesis aspects without the need of consulting to the
"format for theses" handbook included in FBE web page (Format.pdf).



For special cases some of which are:


Sideway figures/tables

Punctuation rules in equations, figures, tables

Page limitation on abstract/ozet pages

List of symbols formatting

In text bullet list / list numbering rules

Figures / Tables spanning 2+ pages

When to use CAPITAL LETTERS

Printer guidelines



you should consult the "format for theses" handbook (Format.pdf) and follow the rules listed in it.

